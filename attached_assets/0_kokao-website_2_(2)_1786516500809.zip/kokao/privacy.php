<?php
// KOKAO — privacy policy, rendered from content.json (edit under "Privacy policy" in /admin.php)
$c = json_decode(file_get_contents(__DIR__ . '/content.json'), true);
if (!$c) { http_response_code(500); exit('Content file missing or invalid.'); }
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$site = $c['site']; $pv = $c['privacy']; $logo = $site['logo'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pv['title']) ?> — <?= e($site['brand']) ?></title>
<meta name="robots" content="noindex, follow">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --bg:<?= e($site['color_bg']) ?>;--ink:<?= e($site['color_ink']) ?>;
  --a1:<?= e($site['color_accent1']) ?>;--a2:<?= e($site['color_accent2']) ?>;--a3:<?= e($site['color_accent3']) ?>;
  --muted:color-mix(in srgb,var(--ink) 62%,transparent);
  --line:color-mix(in srgb,var(--ink) 10%,transparent);
  --ease:cubic-bezier(.22,1,.36,1);
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Sora',system-ui,sans-serif;background:var(--bg);color:var(--ink);line-height:1.7}
a{color:inherit}
.wrap{max-width:720px;margin:0 auto;padding:0 24px}
header{border-bottom:1px solid var(--line)}
.nav{display:flex;align-items:center;justify-content:space-between;height:72px}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:1.15rem;text-decoration:none}
.brand img,.brand svg{width:34px;height:34px;border-radius:10px}
.back{font-size:.9rem;color:var(--muted);text-decoration:none;transition:color .3s}
.back:hover{color:var(--ink)}
main{padding:72px 0 96px}
.eyebrow{display:inline-block;padding:8px 16px;border-radius:999px;background:color-mix(in srgb,var(--a1) 35%,#fff);font-size:.85rem;font-weight:500}
h1{font-size:clamp(2rem,5vw,2.8rem);letter-spacing:-.02em;margin:20px 0 8px}
.updated{color:var(--muted);font-size:.9rem}
.intro{margin-top:28px;font-size:1.02rem}
section{margin-top:44px;opacity:0;transform:translateY(24px);animation:rise .8s var(--ease) forwards;animation-delay:calc(var(--i)*70ms)}
@keyframes rise{to{opacity:1;transform:none}}
h2{font-size:1.2rem;letter-spacing:-.01em;margin-bottom:10px;padding-left:16px;border-left:4px solid var(--a1)}
section:nth-of-type(3n+2) h2{border-color:var(--a2)}
section:nth-of-type(3n) h2{border-color:var(--a3)}
section p{color:var(--muted);font-size:.96rem;margin-top:10px}
footer{padding:40px 0;border-top:1px solid var(--line);color:var(--muted);font-size:.88rem}
.foot{display:flex;justify-content:space-between;gap:20px;flex-wrap:wrap}
.foot nav{display:flex;gap:24px}
.foot a{text-decoration:none}
.foot a:hover{color:var(--ink)}
@media (prefers-reduced-motion:reduce){section{animation:none;opacity:1;transform:none}}
</style>
</head>
<body>

<header>
  <div class="wrap nav">
    <a class="brand" href="index.php">
      <?php if ($logo): ?>
        <img src="<?= e($logo) ?>" alt="<?= e($site['brand']) ?> logo">
      <?php else: ?>
        <svg viewBox="0 0 34 34" aria-hidden="true"><rect width="34" height="34" rx="10" fill="url(#g)"/><defs><linearGradient id="g" x1="0" y1="0" x2="34" y2="34"><stop stop-color="<?= e($site['color_accent1']) ?>"/><stop offset=".5" stop-color="<?= e($site['color_accent2']) ?>"/><stop offset="1" stop-color="<?= e($site['color_accent3']) ?>"/></linearGradient></defs><path d="M11 8v18M11 17l9-9M12.5 15.5L21 26" stroke="<?= e($site['color_ink']) ?>" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>
      <?php endif; ?>
      <?= e($site['brand']) ?>
    </a>
    <a class="back" href="index.php">← Back to site</a>
  </div>
</header>

<main class="wrap">
  <span class="eyebrow">Legal</span>
  <h1><?= e($pv['title']) ?></h1>
  <p class="updated"><?= e($pv['updated']) ?></p>
  <p class="intro"><?= e($pv['intro']) ?></p>

  <?php foreach ($pv['sections'] as $i => $s): ?>
  <section style="--i:<?= $i ?>">
    <h2><?= e($s['heading']) ?></h2>
    <?php foreach (preg_split('/\n\s*\n/', $s['body']) as $para): if (trim($para) === '') continue; ?>
      <p><?= nl2br(e(trim($para))) ?></p>
    <?php endforeach; ?>
  </section>
  <?php endforeach; ?>
</main>

<footer>
  <div class="wrap foot">
    <span><?= e($c['footer']['text']) ?></span>
    <nav>
      <?php foreach ($c['footer']['links'] as $l): ?><a href="<?= e($l['href']) ?>"><?= e($l['label']) ?></a><?php endforeach; ?>
    </nav>
  </div>
</footer>

</body>
</html>
