<?php
// KOKAO CMS — single-file flat-file admin panel. Edits content.json, handles uploads, no database.
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

const CONTENT = __DIR__ . '/content.json';
const CONFIG  = __DIR__ . '/config.php';
const UPLOADS = __DIR__ . '/uploads';
const MAX_UPLOAD = 3 * 1024 * 1024; // 3 MB

$config = require CONFIG;
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$authed = !empty($_SESSION['kokao_auth']);
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
$csrf = $_SESSION['csrf'];
$msg = $err = '';

// ---------- actions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'login') {
    if (password_verify($_POST['password'] ?? '', $config['password_hash'])) {
      session_regenerate_id(true);
      $_SESSION['kokao_auth'] = true;
      header('Location: admin.php'); exit;
    }
    sleep(1); // slow brute force
    $err = 'Wrong password.';
  }

  if ($authed && !hash_equals($csrf, $_POST['csrf'] ?? '')) { http_response_code(403); exit('Invalid CSRF token.'); }

  if ($authed && $action === 'save') {
    $schema = json_decode(file_get_contents(CONTENT), true);
    $data = rebuild($schema, $_POST['d'] ?? []);
    // image uploads: input name uploads[dot.path.to.field]
    foreach (($_FILES['uploads']['name'] ?? []) as $path => $name) {
      if (($_FILES['uploads']['error'][$path] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;
      $tmp = $_FILES['uploads']['tmp_name'][$path];
      if ($_FILES['uploads']['size'][$path] > MAX_UPLOAD) { $err = 'Image too large (max 3 MB).'; continue; }
      $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
      $ok = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/gif' => 'gif'];
      if (!isset($ok[$mime])) { $err = 'Only PNG, JPG, WEBP or GIF images are allowed.'; continue; }
      $file = preg_replace('/[^a-z0-9]/', '', strtolower(pathinfo($name, PATHINFO_FILENAME)));
      $file = substr($file ?: 'img', 0, 24) . '-' . bin2hex(random_bytes(4)) . '.' . $ok[$mime];
      if (move_uploaded_file($tmp, UPLOADS . '/' . $file)) setPath($data, explode('.', $path), 'uploads/' . $file);
    }
    if (!$err) {
      copy(CONTENT, __DIR__ . '/content.backup.json'); // one-step undo
      file_put_contents(CONTENT, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);
      header('Location: admin.php?saved=1'); exit;
    }
  }

  if ($authed && $action === 'password') {
    if (!password_verify($_POST['current'] ?? '', $config['password_hash'])) $err = 'Current password is wrong.';
    elseif (strlen($_POST['new'] ?? '') < 8) $err = 'New password must be at least 8 characters.';
    else {
      $php = "<?php\nreturn ['password_hash' => " . var_export(password_hash($_POST['new'], PASSWORD_DEFAULT), true) . "];\n";
      file_put_contents(CONFIG, $php, LOCK_EX);
      $config = require CONFIG;
      $msg = 'Password updated.';
    }
  }
}
if (($_GET['action'] ?? '') === 'logout') { session_destroy(); header('Location: admin.php'); exit; }
if (isset($_GET['saved'])) $msg = 'Saved! Your changes are live.';

// rebuild POST data using current content.json as the type schema (lists reindexed, bools cast, strings trimmed)
function rebuild($schema, $input) {
  if (is_array($schema)) {
    if ($schema === [] || array_is_list($schema)) {
      $item = $schema[0] ?? '';
      $out = [];
      foreach (array_values(is_array($input) ? $input : []) as $v) $out[] = rebuild($item, $v);
      return $out;
    }
    $out = [];
    foreach ($schema as $k => $v) $out[$k] = rebuild($v, $input[$k] ?? (is_array($v) ? [] : ''));
    return $out;
  }
  if (is_bool($schema)) return !empty($input);
  return trim((string)$input);
}
function setPath(&$arr, $keys, $val) {
  $ref = &$arr;
  foreach ($keys as $k) $ref = &$ref[$k];
  $ref = $val;
}

$content = json_decode(file_get_contents(CONTENT), true);
$defaultPw = password_verify('kokao2026', $config['password_hash']);

// ---------- form renderer ----------
$SECTION_LABELS = [
  'site' => '⚙️ Site & colors', 'nav' => '🧭 Navigation', 'hero' => '🌅 Hero',
  'platforms' => '🔁 Platforms strip', 'features' => '✨ Features', 'how' => '🪜 How it works',
  'pricing' => '💳 Pricing', 'testimonials' => '💬 Testimonials', 'faq' => '❓ FAQ',
  'cta' => '📣 Final call-to-action', 'footer' => '🦶 Footer', 'privacy' => '📜 Privacy policy',
];
function label($k) {
  $nice = ['q' => 'Question', 'a' => 'Answer', 'num' => 'Number', 'cta' => 'Button text', 'cta_link' => 'Button link', 'href' => 'Link', 'items' => 'Item'];
  return $nice[$k] ?? ucfirst(str_replace('_', ' ', $k));
}

function field($name, $key, $val, $path) {
  $id = e($name);
  if (is_bool($val)) {
    echo "<label class='check'><input type='hidden' name='{$id}' value=''><input type='checkbox' name='{$id}' value='1' " . ($val ? 'checked' : '') . "> " . e(label($key)) . "</label>";
    return;
  }
  echo "<label>" . e(label($key));
  if (str_starts_with($key, 'color_')) {
    echo "<span class='colorrow'><input type='color' value='" . e($val) . "' oninput='this.nextElementSibling.value=this.value'><input name='{$id}' value='" . e($val) . "' oninput='this.previousElementSibling.value=this.value'></span>";
  } elseif ($key === 'logo') {
    echo "<input name='{$id}' value='" . e($val) . "' placeholder='Leave empty to use the built-in KOKAO mark'>";
    if ($val) echo "<img class='preview' src='" . e($val) . "' alt='current logo'>";
    echo "<input type='file' name='uploads[" . e($path) . "]' accept='image/png,image/jpeg,image/webp,image/gif'><small>Upload replaces the field above. PNG / JPG / WEBP / GIF, max 3 MB.</small>";
  } elseif (mb_strlen($val) > 90 || in_array($key, ['subtitle', 'text', 'quote', 'a', 'meta_description', 'body', 'intro'])) {
    echo "<textarea name='{$id}' rows='" . (mb_strlen($val) > 300 ? 8 : 3) . "'>" . e($val) . "</textarea>";
  } else {
    echo "<input name='{$id}' value='" . e($val) . "'>";
  }
  echo "</label>";
}

function walk($data, $name, $path) {
  foreach ($data as $k => $v) {
    $n = $name . "[" . $k . "]";
    $p = $path === '' ? $k : $path . '.' . $k;
    if (is_array($v) && array_is_list($v)) {
      echo "<fieldset class='list' data-name='" . e($n) . "'><legend>" . e(label($k)) . "</legend><div class='items'>";
      foreach ($v as $i => $item) {
        echo "<div class='item'><button type='button' class='rm' title='Remove'>✕</button>";
        if (is_array($item)) walk($item, $n . "[$i]", "$p.$i"); else field($n . "[$i]", $k, $item, "$p.$i");
        echo "</div>";
      }
      echo "</div>";
      // template for "add item" based on the first item's shape, values blanked
      $proto = $v[0] ?? '';
      $blank = is_array($proto) ? array_map(fn($x) => is_array($x) ? [] : (is_bool($x) ? false : ''), $proto) : '';
      echo "<template>";
      echo "<div class='item'><button type='button' class='rm' title='Remove'>✕</button>";
      if (is_array($blank)) walk($blank, $n . "[__IDX__]", "$p.__IDX__"); else field($n . "[__IDX__]", $k, '', "$p.__IDX__");
      echo "</div></template><button type='button' class='add'>+ Add " . e(rtrim(label($k), 's')) . "</button></fieldset>";
    } elseif (is_array($v)) {
      walk($v, $n, $p);
    } else {
      field($n, $k, $v, $p);
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>KOKAO CMS</title>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#FBF9F6;--ink:#1F1B2E;--a1:#C9BBF5;--a2:#FFD9C7;--a3:#C9EEDC;--line:#e8e4dd;--muted:#7c7787}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Sora',system-ui,sans-serif;background:var(--bg);color:var(--ink);line-height:1.55}
.wrap{max-width:860px;margin:0 auto;padding:24px 20px 140px}
.topbar{position:sticky;top:0;z-index:10;background:rgba(251,249,246,.9);backdrop-filter:blur(10px);border-bottom:1px solid var(--line)}
.topbar .in{max-width:860px;margin:0 auto;padding:14px 20px;display:flex;align-items:center;gap:14px}
.topbar b{font-size:1.05rem}
.topbar .sp{flex:1}
.topbar a{color:var(--muted);text-decoration:none;font-size:.88rem}
.topbar a:hover{color:var(--ink)}
.flash{margin:18px 0;padding:13px 18px;border-radius:12px;font-size:.92rem}
.ok{background:#e3f6ea;border:1px solid #b7e6c8}
.bad{background:#fde8e4;border:1px solid #f6c1b7}
.warn{background:#fff3d6;border:1px solid #f0dfa8}
details.panel{background:#fff;border:1px solid var(--line);border-radius:16px;margin:14px 0;overflow:hidden}
details.panel>summary{cursor:pointer;padding:16px 20px;font-weight:600;list-style:none;display:flex;justify-content:space-between}
details.panel>summary::-webkit-details-marker{display:none}
details.panel>summary::after{content:'▾';color:var(--muted);transition:transform .3s}
details.panel[open]>summary::after{transform:rotate(180deg)}
.body{padding:4px 20px 20px;border-top:1px solid var(--line);display:grid;gap:14px}
label{display:grid;gap:6px;font-size:.85rem;font-weight:600}
input,textarea{font:inherit;font-weight:400;padding:10px 12px;border:1px solid var(--line);border-radius:10px;background:#fff;width:100%}
input:focus,textarea:focus{outline:2px solid var(--a1);border-color:transparent}
textarea{resize:vertical}
.check{display:flex;align-items:center;gap:9px}
.check input[type=checkbox]{width:auto;accent-color:var(--ink)}
.colorrow{display:flex;gap:8px}
.colorrow input[type=color]{width:48px;padding:2px;height:42px}
fieldset.list{border:1px dashed var(--line);border-radius:14px;padding:14px;display:grid;gap:10px}
legend{font-weight:600;font-size:.85rem;padding:0 8px}
.items{display:grid;gap:10px}
.item{position:relative;background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:14px;display:grid;gap:12px}
.rm{position:absolute;top:8px;right:8px;border:none;background:transparent;color:var(--muted);cursor:pointer;font-size:.9rem;line-height:1;padding:6px}
.rm:hover{color:#c0392b}
.add{justify-self:start;border:1px solid var(--line);background:#fff;border-radius:999px;padding:8px 16px;font:inherit;font-size:.85rem;cursor:pointer}
.add:hover{border-color:var(--a1)}
.preview{max-height:56px;border:1px solid var(--line);border-radius:10px;padding:6px;background:#fff}
small{color:var(--muted);font-weight:400}
.savebar{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.92);backdrop-filter:blur(10px);border-top:1px solid var(--line);padding:14px 20px}
.savebar .in{max-width:860px;margin:0 auto;display:flex;gap:12px;align-items:center}
.btn{border:none;font:inherit;font-weight:600;padding:13px 30px;border-radius:999px;background:var(--ink);color:#fff;cursor:pointer;transition:transform .3s,box-shadow .3s}
.btn:hover{transform:translateY(-2px);box-shadow:0 12px 24px -12px rgba(31,27,46,.5)}
.login{max-width:380px;margin:14vh auto;background:#fff;border:1px solid var(--line);border-radius:20px;padding:36px;display:grid;gap:16px}
.login .mark{width:48px;height:48px;border-radius:14px;background:linear-gradient(135deg,var(--a1),var(--a2),var(--a3));display:grid;place-items:center;font-weight:700;font-size:1.3rem}
.pw{display:grid;gap:12px;max-width:420px}
</style>
</head>
<body>

<?php if (!$authed): ?>
  <form class="login" method="post">
    <div class="mark">K</div>
    <div><b>KOKAO CMS</b><br><small>Sign in to edit your site</small></div>
    <?php if ($err): ?><div class="flash bad"><?= e($err) ?></div><?php endif; ?>
    <input type="hidden" name="action" value="login">
    <label>Password<input type="password" name="password" required autofocus></label>
    <button class="btn">Sign in</button>
  </form>

<?php else: ?>
  <div class="topbar"><div class="in">
    <b>KOKAO CMS</b><span class="sp"></span>
    <a href="index.php" target="_blank">View site ↗</a>
    <a href="#password">Password</a>
    <a href="admin.php?action=logout">Log out</a>
  </div></div>

  <div class="wrap">
    <?php if ($msg): ?><div class="flash ok"><?= e($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="flash bad"><?= e($err) ?></div><?php endif; ?>
    <?php if ($defaultPw): ?><div class="flash warn">You're using the default password (<code>kokao2026</code>). Change it below before going live.</div><?php endif; ?>

    <form method="post" enctype="multipart/form-data" id="cms">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
      <?php foreach ($content as $section => $data): ?>
        <details class="panel" <?= $section === 'site' ? 'open' : '' ?>>
          <summary><?= e($SECTION_LABELS[$section] ?? ucfirst($section)) ?></summary>
          <div class="body"><?php walk($data, "d[$section]", $section); ?></div>
        </details>
      <?php endforeach; ?>
    </form>

    <details class="panel" id="password">
      <summary>🔒 Change password</summary>
      <div class="body">
        <form method="post" class="pw">
          <input type="hidden" name="action" value="password">
          <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
          <label>Current password<input type="password" name="current" required></label>
          <label>New password (min 8 chars)<input type="password" name="new" minlength="8" required></label>
          <button class="btn">Update password</button>
        </form>
      </div>
    </details>
  </div>

  <div class="savebar"><div class="in">
    <button class="btn" form="cms">Save & publish</button>
    <small>Writes content.json instantly — a backup of the previous version is kept.</small>
  </div></div>

  <script>
  let idx = 1000;
  document.addEventListener('click', e => {
    if (e.target.classList.contains('add')) {
      const fs = e.target.closest('fieldset');
      const html = fs.querySelector(':scope > template').innerHTML.replaceAll('__IDX__', 'n' + (idx++));
      fs.querySelector(':scope > .items').insertAdjacentHTML('beforeend', html);
    }
    if (e.target.classList.contains('rm')) e.target.closest('.item').remove();
  });
  // warn about unsaved changes
  let dirty = false;
  document.getElementById('cms').addEventListener('input', () => dirty = true);
  document.getElementById('cms').addEventListener('submit', () => dirty = false);
  window.addEventListener('beforeunload', e => { if (dirty) e.preventDefault(); });
  </script>
<?php endif; ?>
</body>
</html>
