# KOKAO — Landing Page + CMS

A one-page landing site with a built-in flat-file CMS. No database. Works on any PHP hosting (PHP 8.0+).

## Install (cPanel / shared hosting)

1. Upload everything in this folder to `public_html/` (or a subfolder) — via cPanel File Manager or FTP.
2. Visit `yourdomain.com` — the site is live.
3. Visit `yourdomain.com/admin.php` — log in with the default password: `kokao2026`
4. **Change the password immediately** (🔒 Change password, at the bottom of the admin).

That's it.

## Editing your site

Everything on the page is editable at `/admin.php`:

- **Site & colors** — brand name, logo upload, SEO title/description, the 4 pastel theme colours
- **Every section** — hero, features, steps, pricing plans, testimonials, FAQ, CTA, footer
- **+ Add / ✕ Remove** items in any list (features, plans, FAQs…)
- Hit **Save & publish** — changes are live instantly. The previous version is kept as `content.backup.json` (copy it over `content.json` to undo).

## Logo

Upload your logo in **Site & colors** (PNG/JPG/WEBP/GIF, max 3 MB). Leave the field empty to use the built-in pastel "K" mark.

## Files

| File | Purpose |
|---|---|
| `index.php` | The landing page (renders `content.json`) |
| `privacy.php` | Privacy policy page (editable in the CMS under 📜 Privacy policy) |
| `admin.php` | The CMS |
| `content.json` | All site content |
| `config.php` | Admin password hash |
| `uploads/` | Uploaded images (script execution blocked) |

## Requirements

PHP 8.0+ with the `fileinfo` extension (standard on virtually all hosts). The folder must be writable by PHP (default on shared hosting).
