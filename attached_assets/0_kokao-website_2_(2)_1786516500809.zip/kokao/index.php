<?php
// KOKAO — one-page landing rendered from content.json (edit everything at /admin.php)
$c = json_decode(file_get_contents(__DIR__ . '/content.json'), true);
if (!$c) { http_response_code(500); exit('Content file missing or invalid.'); }
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$site = $c['site'];
$logo = $site['logo'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($site['meta_title']) ?></title>
<meta name="description" content="<?= e($site['meta_description']) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --bg:<?= e($site['color_bg']) ?>;
  --ink:<?= e($site['color_ink']) ?>;
  --a1:<?= e($site['color_accent1']) ?>;
  --a2:<?= e($site['color_accent2']) ?>;
  --a3:<?= e($site['color_accent3']) ?>;
  --muted:color-mix(in srgb,var(--ink) 62%,transparent);
  --line:color-mix(in srgb,var(--ink) 10%,transparent);
  --card:#fff;
  --r:20px;
  --ease:cubic-bezier(.22,1,.36,1);
}
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{font-family:'Sora',system-ui,sans-serif;background:var(--bg);color:var(--ink);line-height:1.6;overflow-x:hidden}
a{color:inherit;text-decoration:none}
img{max-width:100%;display:block}
.wrap{max-width:1120px;margin:0 auto;padding:0 24px}
section{padding:96px 0}
h1,h2,h3{line-height:1.15;font-weight:700;letter-spacing:-.02em}
h2{font-size:clamp(1.8rem,4vw,2.6rem)}
.sub{color:var(--muted);max-width:560px;margin:14px auto 0;text-align:center}
.center{text-align:center}

/* buttons */
.btn{display:inline-block;padding:14px 28px;border-radius:999px;font-weight:600;font-size:.95rem;transition:transform .35s var(--ease),box-shadow .35s var(--ease),background .35s}
.btn-primary{background:var(--ink);color:var(--bg)}
.btn-primary:hover{transform:translateY(-3px);box-shadow:0 14px 30px -12px color-mix(in srgb,var(--ink) 45%,transparent)}
.btn-ghost{border:1px solid var(--line);background:#fff}
.btn-ghost:hover{transform:translateY(-3px);border-color:var(--a1);box-shadow:0 14px 30px -16px var(--a1)}

/* header */
header{position:fixed;inset:0 0 auto;z-index:50;transition:background .4s,box-shadow .4s;backdrop-filter:blur(0px)}
header.scrolled{background:color-mix(in srgb,var(--bg) 82%,transparent);backdrop-filter:blur(14px);box-shadow:0 1px 0 var(--line)}
.nav{display:flex;align-items:center;justify-content:space-between;height:72px}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:1.15rem;letter-spacing:.02em}
.brand img,.brand svg{width:34px;height:34px;border-radius:10px}
.nav-links{display:flex;gap:32px;font-size:.92rem}
.nav-links a{color:var(--muted);transition:color .3s}
.nav-links a:hover{color:var(--ink)}
.nav .btn{padding:10px 20px}
@media(max-width:760px){.nav-links{display:none}}

/* hero */
.hero{padding:170px 0 90px;position:relative}
.blob{position:absolute;border-radius:50%;filter:blur(80px);opacity:.55;z-index:-1;animation:drift 16s ease-in-out infinite alternate}
.b1{width:420px;height:420px;background:var(--a1);top:-80px;left:-120px}
.b2{width:360px;height:360px;background:var(--a2);top:120px;right:-100px;animation-delay:-5s}
.b3{width:300px;height:300px;background:var(--a3);bottom:-120px;left:35%;animation-delay:-9s}
@keyframes drift{from{transform:translate(0,0) scale(1)}to{transform:translate(40px,30px) scale(1.12)}}
.hero-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:64px;align-items:center}
@media(max-width:900px){.hero-grid{grid-template-columns:1fr;gap:48px}}
.badge{display:inline-block;padding:8px 16px;border-radius:999px;background:color-mix(in srgb,var(--a1) 35%,#fff);font-size:.85rem;font-weight:500}
.hero h1{font-size:clamp(2.5rem,5.5vw,3.9rem);margin:22px 0 18px}
.hero p.lead{color:var(--muted);font-size:1.08rem;max-width:520px}
.hero-ctas{display:flex;gap:14px;margin-top:32px;flex-wrap:wrap}
.stats{display:flex;gap:40px;margin-top:52px;flex-wrap:wrap}
.stat b{font-size:1.6rem;font-weight:700;display:block}
.stat span{color:var(--muted);font-size:.85rem}
/* staged entrance */
.up{opacity:0;transform:translateY(26px);animation:rise .9s var(--ease) forwards}
@keyframes rise{to{opacity:1;transform:none}}
.d1{animation-delay:.05s}.d2{animation-delay:.15s}.d3{animation-delay:.25s}.d4{animation-delay:.35s}.d5{animation-delay:.5s}

/* hero mock card */
.mock{background:#fff;border:1px solid var(--line);border-radius:24px;padding:26px;box-shadow:0 30px 60px -30px color-mix(in srgb,var(--ink) 25%,transparent);animation:float 7s ease-in-out infinite}
@keyframes float{0%,100%{transform:translateY(0) rotate(.4deg)}50%{transform:translateY(-14px) rotate(-.4deg)}}
.mock-top{display:flex;gap:7px;margin-bottom:20px}
.mock-top i{width:10px;height:10px;border-radius:50%;background:var(--line)}
.mock-top i:nth-child(1){background:var(--a2)}.mock-top i:nth-child(2){background:var(--a1)}.mock-top i:nth-child(3){background:var(--a3)}
.type-line{font-size:.92rem;color:var(--muted);border:1px solid var(--line);border-radius:12px;padding:13px 16px;min-height:48px}
.type-line::after{content:'';display:inline-block;width:2px;height:1em;background:var(--ink);margin-left:2px;vertical-align:-2px;animation:blink 1s steps(1) infinite}
@keyframes blink{50%{opacity:0}}
.mock-img{height:150px;border-radius:14px;margin:16px 0;background:linear-gradient(120deg,var(--a1),var(--a2),var(--a3));background-size:200% 200%;animation:sheen 5s ease infinite}
@keyframes sheen{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
.mock-bars span{display:block;height:9px;border-radius:5px;background:var(--line);margin:9px 0}
.mock-bars span:nth-child(1){width:88%}.mock-bars span:nth-child(2){width:64%}
.mock-status{display:flex;align-items:center;gap:9px;margin-top:18px;font-size:.82rem;color:var(--muted)}
.pulse{width:9px;height:9px;border-radius:50%;background:#5EC98F;animation:pulse 1.8s ease infinite}
@keyframes pulse{50%{box-shadow:0 0 0 7px color-mix(in srgb,#5EC98F 25%,transparent)}}

/* marquee */
.marquee-sec{padding:40px 0 72px}
.marquee-sec h3{text-align:center;color:var(--muted);font-weight:500;font-size:.95rem;margin-bottom:30px}
.marquee{overflow:hidden;mask:linear-gradient(90deg,transparent,#000 12%,#000 88%,transparent)}
.track{display:flex;gap:16px;width:max-content;animation:scroll 26s linear infinite}
.marquee:hover .track{animation-play-state:paused}
@keyframes scroll{to{transform:translateX(-50%)}}
.chip{padding:12px 26px;border-radius:999px;background:#fff;border:1px solid var(--line);font-weight:600;font-size:.95rem;white-space:nowrap}

/* reveal on scroll */
.reveal{opacity:0;transform:translateY(34px);transition:opacity .8s var(--ease),transform .8s var(--ease);transition-delay:calc(var(--i,0)*90ms)}
.reveal.in{opacity:1;transform:none}

/* features */
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;margin-top:56px}
@media(max-width:900px){.grid3{grid-template-columns:1fr 1fr}}
@media(max-width:620px){.grid3{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:30px;transition:transform .45s var(--ease),box-shadow .45s var(--ease),border-color .45s}
.card:hover{transform:translateY(-7px);box-shadow:0 24px 44px -24px color-mix(in srgb,var(--ink) 22%,transparent);border-color:var(--a1)}
.icon{width:52px;height:52px;border-radius:15px;display:grid;place-items:center;font-size:1.4rem;margin-bottom:18px;transition:transform .45s var(--ease)}
.card:hover .icon{transform:scale(1.1) rotate(-6deg)}
.grid3 .card:nth-child(3n+1) .icon{background:color-mix(in srgb,var(--a1) 45%,#fff)}
.grid3 .card:nth-child(3n+2) .icon{background:color-mix(in srgb,var(--a2) 45%,#fff)}
.grid3 .card:nth-child(3n) .icon{background:color-mix(in srgb,var(--a3) 45%,#fff)}
.card h3{font-size:1.1rem;margin-bottom:8px}
.card p{color:var(--muted);font-size:.93rem}

/* how */
.steps{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;margin-top:56px;counter-reset:step}
@media(max-width:760px){.steps{grid-template-columns:1fr}}
.step{position:relative;padding:34px 28px;border-radius:var(--r);background:#fff;border:1px solid var(--line)}
.step::before{counter-increment:step;content:counter(step,decimal-leading-zero);font-weight:700;font-size:.85rem;display:inline-grid;place-items:center;width:42px;height:42px;border-radius:50%;background:var(--ink);color:var(--bg);margin-bottom:18px}
.step h3{font-size:1.08rem;margin-bottom:8px}
.step p{color:var(--muted);font-size:.93rem}

/* pricing */
.plans{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;margin-top:56px;align-items:stretch}
@media(max-width:860px){.plans{grid-template-columns:1fr}}
.plan{position:relative;background:#fff;border:1px solid var(--line);border-radius:24px;padding:36px 30px;display:flex;flex-direction:column;transition:transform .45s var(--ease),box-shadow .45s var(--ease)}
.plan:hover{transform:translateY(-7px);box-shadow:0 26px 48px -26px color-mix(in srgb,var(--ink) 25%,transparent)}
.plan.featured{border:2px solid transparent;background:linear-gradient(#fff,#fff) padding-box,linear-gradient(135deg,var(--a1),var(--a2),var(--a3)) border-box;box-shadow:0 26px 52px -26px color-mix(in srgb,var(--a1) 80%,var(--ink))}
.plan .tag{position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:var(--ink);color:var(--bg);font-size:.75rem;font-weight:600;padding:6px 16px;border-radius:999px;white-space:nowrap}
.plan h3{font-size:1.05rem}
.price{font-size:2.5rem;font-weight:700;margin:12px 0 4px}
.price small{font-size:.95rem;color:var(--muted);font-weight:400}
.plan ul{list-style:none;margin:22px 0 30px;flex:1}
.plan li{padding:7px 0 7px 28px;position:relative;font-size:.92rem;color:var(--muted)}
.plan li::before{content:'✓';position:absolute;left:0;font-weight:700;color:var(--ink)}
.plan .btn{text-align:center}

/* testimonials */
.quotes{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;margin-top:56px}
@media(max-width:860px){.quotes{grid-template-columns:1fr}}
.quote{background:#fff;border:1px solid var(--line);border-radius:var(--r);padding:30px}
.quote p{font-size:.97rem;margin-bottom:20px}
.quote p::before{content:'“'}.quote p::after{content:'”'}
.who b{display:block;font-size:.92rem}
.who span{color:var(--muted);font-size:.82rem}

/* faq */
.faq{max-width:720px;margin:48px auto 0}
details{border-bottom:1px solid var(--line)}
summary{cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:16px;padding:22px 4px;font-weight:600}
summary::-webkit-details-marker{display:none}
summary::after{content:'+';font-size:1.4rem;font-weight:400;color:var(--muted);transition:transform .4s var(--ease)}
details[open] summary::after{transform:rotate(45deg)}
.ans{overflow:hidden;color:var(--muted);font-size:.94rem;padding:0 4px}
details .ans{max-height:0;transition:max-height .5s var(--ease),padding .5s var(--ease)}
details[open] .ans{max-height:300px;padding-bottom:22px}

/* final cta */
.cta-panel{border-radius:32px;padding:80px 32px;text-align:center;background:linear-gradient(135deg,color-mix(in srgb,var(--a1) 55%,#fff),color-mix(in srgb,var(--a2) 55%,#fff) 50%,color-mix(in srgb,var(--a3) 55%,#fff));background-size:180% 180%;animation:sheen 9s ease infinite}
.cta-panel h2{max-width:640px;margin:0 auto}
.cta-panel p{color:color-mix(in srgb,var(--ink) 70%,transparent);margin:16px auto 34px;max-width:480px}

/* footer */
footer{padding:44px 0;border-top:1px solid var(--line)}
.foot{display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap;font-size:.88rem;color:var(--muted)}
.foot nav{display:flex;gap:24px}
.foot a:hover{color:var(--ink)}

@media (prefers-reduced-motion:reduce){
  *,*::before,*::after{animation:none!important;transition:none!important}
  .up,.reveal{opacity:1;transform:none}
  html{scroll-behavior:auto}
}
</style>
</head>
<body>

<header id="hd">
  <div class="wrap nav">
    <a class="brand" href="#">
      <?php if ($logo): ?>
        <img src="<?= e($logo) ?>" alt="<?= e($site['brand']) ?> logo">
      <?php else: ?>
        <svg viewBox="0 0 34 34" aria-hidden="true"><rect width="34" height="34" rx="10" fill="url(#g)"/><defs><linearGradient id="g" x1="0" y1="0" x2="34" y2="34"><stop stop-color="<?= e($site['color_accent1']) ?>"/><stop offset=".5" stop-color="<?= e($site['color_accent2']) ?>"/><stop offset="1" stop-color="<?= e($site['color_accent3']) ?>"/></linearGradient></defs><path d="M11 8v18M11 17l9-9M12.5 15.5L21 26" stroke="<?= e($site['color_ink']) ?>" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>
      <?php endif; ?>
      <?= e($site['brand']) ?>
    </a>
    <nav class="nav-links">
      <?php foreach ($c['nav']['links'] as $l): ?><a href="<?= e($l['href']) ?>"><?= e($l['label']) ?></a><?php endforeach; ?>
    </nav>
    <a class="btn btn-primary" href="<?= e($c['nav']['cta_link']) ?>"><?= e($c['nav']['cta']) ?></a>
  </div>
</header>

<section class="hero">
  <div class="blob b1"></div><div class="blob b2"></div><div class="blob b3"></div>
  <div class="wrap hero-grid">
    <div>
      <span class="badge up d1"><?= e($c['hero']['badge']) ?></span>
      <h1 class="up d2"><?= e($c['hero']['title']) ?></h1>
      <p class="lead up d3"><?= e($c['hero']['subtitle']) ?></p>
      <div class="hero-ctas up d4">
        <a class="btn btn-primary" href="<?= e($c['hero']['cta_primary_link']) ?>"><?= e($c['hero']['cta_primary']) ?></a>
        <a class="btn btn-ghost" href="<?= e($c['hero']['cta_secondary_link']) ?>"><?= e($c['hero']['cta_secondary']) ?></a>
      </div>
      <div class="stats up d5">
        <?php foreach ($c['hero']['stats'] as $s): ?>
          <div class="stat"><b data-count><?= e($s['num']) ?></b><span><?= e($s['label']) ?></span></div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="up d3">
      <div class="mock">
        <div class="mock-top"><i></i><i></i><i></i></div>
        <div class="type-line" id="typeline" data-text="<?= e($c['hero']['card_prompt']) ?>"></div>
        <div class="mock-img"></div>
        <div class="mock-bars"><span></span><span></span></div>
        <div class="mock-status"><i class="pulse"></i><?= e($c['hero']['card_status']) ?></div>
      </div>
    </div>
  </div>
</section>

<section class="marquee-sec" id="platforms">
  <h3 class="reveal"><?= e($c['platforms']['title']) ?></h3>
  <div class="marquee reveal">
    <div class="track">
      <?php for ($r = 0; $r < 2; $r++) foreach ($c['platforms']['items'] as $p): ?><span class="chip"><?= e($p) ?></span><?php endforeach; ?>
    </div>
  </div>
</section>

<section id="features">
  <div class="wrap">
    <h2 class="center reveal"><?= e($c['features']['title']) ?></h2>
    <p class="sub reveal"><?= e($c['features']['subtitle']) ?></p>
    <div class="grid3">
      <?php foreach ($c['features']['items'] as $i => $f): ?>
      <div class="card reveal" style="--i:<?= $i % 3 ?>">
        <div class="icon"><?= e($f['icon']) ?></div>
        <h3><?= e($f['title']) ?></h3>
        <p><?= e($f['text']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="how">
  <div class="wrap">
    <h2 class="center reveal"><?= e($c['how']['title']) ?></h2>
    <p class="sub reveal"><?= e($c['how']['subtitle']) ?></p>
    <div class="steps">
      <?php foreach ($c['how']['steps'] as $i => $s): ?>
      <div class="step reveal" style="--i:<?= $i ?>"><h3><?= e($s['title']) ?></h3><p><?= e($s['text']) ?></p></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="pricing">
  <div class="wrap">
    <h2 class="center reveal"><?= e($c['pricing']['title']) ?></h2>
    <p class="sub reveal"><?= e($c['pricing']['subtitle']) ?></p>
    <div class="plans">
      <?php foreach ($c['pricing']['plans'] as $i => $p): ?>
      <div class="plan reveal <?= !empty($p['featured']) ? 'featured' : '' ?>" style="--i:<?= $i ?>">
        <?php if (!empty($p['tag'])): ?><span class="tag"><?= e($p['tag']) ?></span><?php endif; ?>
        <h3><?= e($p['name']) ?></h3>
        <div class="price"><?= e($p['price']) ?><small><?= e($p['period']) ?></small></div>
        <ul><?php foreach ($p['features'] as $f): ?><li><?= e($f) ?></li><?php endforeach; ?></ul>
        <a class="btn <?= !empty($p['featured']) ? 'btn-primary' : 'btn-ghost' ?>" href="<?= e($p['cta_link']) ?>"><?= e($p['cta']) ?></a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="testimonials">
  <div class="wrap">
    <h2 class="center reveal"><?= e($c['testimonials']['title']) ?></h2>
    <div class="quotes">
      <?php foreach ($c['testimonials']['items'] as $i => $t): ?>
      <div class="quote reveal" style="--i:<?= $i ?>">
        <p><?= e($t['quote']) ?></p>
        <div class="who"><b><?= e($t['name']) ?></b><span><?= e($t['role']) ?></span></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="faq">
  <div class="wrap">
    <h2 class="center reveal"><?= e($c['faq']['title']) ?></h2>
    <div class="faq reveal">
      <?php foreach ($c['faq']['items'] as $f): ?>
      <details><summary><?= e($f['q']) ?></summary><div class="ans"><?= e($f['a']) ?></div></details>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="cta" style="padding-top:0">
  <div class="wrap">
    <div class="cta-panel reveal">
      <h2><?= e($c['cta']['title']) ?></h2>
      <p><?= e($c['cta']['subtitle']) ?></p>
      <a class="btn btn-primary" href="<?= e($c['cta']['link']) ?>"><?= e($c['cta']['button']) ?></a>
    </div>
  </div>
</section>

<footer>
  <div class="wrap foot">
    <span><?= e($c['footer']['text']) ?></span>
    <nav>
      <?php foreach ($c['footer']['links'] as $l): ?><a href="<?= e($l['href']) ?>"><?= e($l['label']) ?></a><?php endforeach; ?>
    </nav>
  </div>
</footer>

<script>
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

// header shadow on scroll
const hd = document.getElementById('hd');
addEventListener('scroll', () => hd.classList.toggle('scrolled', scrollY > 10), {passive:true});

// scroll reveal
const io = new IntersectionObserver(es => es.forEach(en => {
  if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
}), {threshold:.15});
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

// hero typing effect
const tl = document.getElementById('typeline');
if (tl) {
  const text = tl.dataset.text;
  if (reduce) { tl.textContent = text; }
  else {
    let i = 0;
    (function type(){ if (i <= text.length) { tl.textContent = text.slice(0, i++); setTimeout(type, 34); } })();
  }
}

// stat count-up (animates the numeric part, keeps prefix/suffix)
if (!reduce) document.querySelectorAll('[data-count]').forEach(el => {
  const m = el.textContent.match(/^([^0-9]*)([\d,.]+)(.*)$/);
  if (!m) return;
  const target = parseFloat(m[2].replace(/,/g, '')), dec = (m[2].split('.')[1] || '').length;
  const obs = new IntersectionObserver(es => {
    if (!es[0].isIntersecting) return; obs.disconnect();
    const t0 = performance.now(), dur = 1400;
    (function tick(now){
      const p = Math.min((now - t0) / dur, 1), v = target * (1 - Math.pow(1 - p, 3));
      el.textContent = m[1] + v.toFixed(dec).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + m[3];
      if (p < 1) requestAnimationFrame(tick);
    })(t0);
  });
  obs.observe(el);
});
</script>
</body>
</html>
