<?php
// KOKAO CMS config — regenerated automatically when you change your password in the admin panel.
// Default password: kokao2026  (change it right after your first login!)
return [
  'password_hash' => '$2y$12$.Mjpm1S1V2hg58cHpmPE7ONS03uZ1lpaf87z/tYltpsAXtLfYmq8W',
];
